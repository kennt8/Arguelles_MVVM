package com.example.arguelles_mvvm;

public class FoodItems {

    int image;
    String foodName;
    String foodPrice;

    public FoodItems(int image, String foodName, String foodPrice) {
        this.image = image;
        this.foodName = foodName;
        this.foodPrice = foodPrice;
    }

    public int getImage() {
        return image;
    }

    public String getFoodName() {
        return foodName;
    }

    public String getFoodPrice() {
        return foodPrice;
    }
}
